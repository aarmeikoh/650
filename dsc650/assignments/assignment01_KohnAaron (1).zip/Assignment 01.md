---
title: Assignment 1
subtitle: Computer performance, reliability, and scalability calculation
author: Aaron Kohn
---

## 1.2 

#### a. Data Sizes

| Data Item                                  | Size per Item | 
|--------------------------------------------|--------------:|
| 128 character message.                     | 128 Bytes     | # if using utf-8 and all characters are normal english
| 1024x768 PNG image                         | 1.1 MB        | # https://www.scantips.com/basics1d.html
| 1024x768 RAW image                         | 2.25 MB       | # 1024 x 768 x 3 / 1,048,576 https://www.scantips.com/basics1d.html
| HD (1080p) HEVC Video (15 minutes)         | 879 MB        | # https://www.videoproc.com/edit-4k-video/video-size-calculator.htm
| HD (1080p) Uncompressed Video (15 minutes) | 170,000 MB    | # https://www.videoproc.com/edit-4k-video/video-size-calculator.htm
| 4K UHD HEVC Video (15 minutes)             | 2,625 MB      | # https://www.macxdvd.com/mac-video-converter-pro/4k-video-file-size.htm
| 4k UHD Uncompressed Video (15 minutes)     | 427,170 MB    | # https://www.videoproc.com/edit-4k-video/video-size-calculator.htm
| Human Genome (Uncompressed)                | 3 GB          | # if each base pair given a byte https://www.pbs.org/wgbh/nova/genome/facts.html


#### b. Scaling

|                                           | Size     | # HD | 
|-------------------------------------------|---------:|-----:|
| Daily Twitter Tweets (Uncompressed)       | 59.6 GB  |  1   | # 59.6 x 3 = 178.8 
| Daily Twitter Tweets (Snappy Compressed)  | 37.25 GB |  1   | # 37.25 x 3 = 23.28
| Daily Instagram Photos                    | 82.5 TB  |  25  | # 82.5 x 3 = 247.5
| Daily YouTube Videos                      |2531.52 TB|  76  | # 500 x 60 x 24 = 720000 hr x (879 mb x 4) = 2,531.52 tb x 3 = 759.456 Tb
| Yearly Twitter Tweets (Uncompressed)      |21.754 TB |  7   | # 21.754 x 3 = 65.262
| Yearly Twitter Tweets (Snappy Compressed) | 13.596 TB|  5   | # 13.596 x 3 = 40.788
| Yearly Instagram Photos                   |30112.5 TB| 9034 | # 30112.5 x 3 = 90337.5
| Yearly YouTube Videos                     |924008.4TB|277202| #  924008.4 x3 = 2,772,014.4

#### c. Reliability
|                                    | # HD | # Failures | # Blackblaze Annual Failure Rate = 1.1 %
|------------------------------------|-----:|-----------:|
| Twitter Tweets (Uncompressed)      | 7    |     0.08   |
| Twitter Tweets (Snappy Compressed) | 5    |     0.06   |
| Instagram Photos                   | 9034 |     99.4   |
| YouTube Videos                     |277202|     3049.2 |

#### d. Latency

|                           | One Way Latency      |
|---------------------------|---------------------:|
| Los Angeles to Amsterdam  | 141 ms               | # https://wondernetwork.com/pings/Los%20Angeles/Amsterdam
| Low Earth Orbit Satellite | 20 ms                | # 40 ms round trip latency https://www.omniaccess.com/leo/
| Geostationary Satellite   | 120 ms               | # 240 ms round trip https://www.satsig.net/latency.htm
| Earth to the Moon         | 1300 ms              | # https://www.spaceacademy.net.au/spacelink/commdly.htm
| Earth to Mars             | 3 - 21 minutes       | # distance to mars varies https://www.spaceacademy.net.au/spacelink/commdly.htm
